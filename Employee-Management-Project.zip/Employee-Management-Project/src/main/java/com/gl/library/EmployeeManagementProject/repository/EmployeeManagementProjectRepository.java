package com.gl.library.EmployeeManagementProject.repository;

import org.springframework.data.jpa.repository.JpaRepository;

import com.gl.library.EmployeeManagementProject.Entity.Employee;

public interface EmployeeManagementProjectRepository extends JpaRepository<Employee, Integer> {

}
