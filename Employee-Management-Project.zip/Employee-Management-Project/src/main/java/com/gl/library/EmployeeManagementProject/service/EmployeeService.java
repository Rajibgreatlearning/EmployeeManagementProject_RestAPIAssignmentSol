package com.gl.library.EmployeeManagementProject.service;

import java.util.List;

import com.gl.library.EmployeeManagementProject.Entity.Employee;

public interface EmployeeService {

  /* add employee details in H2 database*/
   String addSingleEmployee(Employee employee);
   String addMultipleEmployee(List<Employee> employee);
   
  /* read employee details from H2 database*/
   List<Employee> getAllEmployee();
   List<Employee> getAllEmployeeSortedByFirstName();
   Employee getEmployeeById(int id);
   List<Employee> getEmployeeByFirstName(String firstName);
   
   /*update employee details in H2 database*/
   String updateEmployee(int id,String newFirstName, String newLastName, String newEmail);
   
   /*delete employee in H2 database*/
   String delateSingleEmployee(Employee employee);
   String deleteEmployeeInBatch();
   String deleteAllEmployee(List<Employee> employee);
   String deleteEmployeeById(int id);
   
}
