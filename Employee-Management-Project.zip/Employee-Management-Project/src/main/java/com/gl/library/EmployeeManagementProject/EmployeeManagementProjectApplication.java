package com.gl.library.EmployeeManagementProject;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

import lombok.extern.slf4j.Slf4j;

@SpringBootApplication
@Slf4j
public class EmployeeManagementProjectApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployeeManagementProjectApplication.class, args);
		System.out.println("Welcome to Employee Management Project");
	}

}
