package com.gl.library.EmployeeManagementProject.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.gl.library.EmployeeManagementProject.Entity.Employee;
import com.gl.library.EmployeeManagementProject.service.EmployeeService;

@RestController
@RequestMapping("/employeeService")
public class EmployeeManagementController {
	@Autowired
	EmployeeService es;

	@PostMapping("/createEmployee")
	public String createEmployee(Employee employee) {
		return es.addSingleEmployee(employee);
	}

	@PostMapping("/createMultipleEmployee")
	public String createMultipleEmployee(@RequestBody List<Employee> employee) {
		return es.addMultipleEmployee(employee);
	}

	@GetMapping("/readAllEmployee")
	public List<Employee> readAllEmployee() {
		return es.getAllEmployee();

	}

	@GetMapping("/readAllEmployeeSorted")
	public List<Employee> readAllEmployeeSorted() {
		return es.getAllEmployeeSortedByFirstName();

	}
	
	@GetMapping("/searchById")
	public Employee findById(int id){
		return es.getEmployeeById(id);
	}
	
	@GetMapping("/searchByFirstName")
	public List<Employee> searchByFirstName(String firstName){
		return es.getEmployeeByFirstName(firstName);
	}
	
	@PostMapping("/updateEmployee")
	public String updateEmployee(int id, String newFirstName, String newLastName, String newEmail){
		return es.updateEmployee(id, newFirstName, newLastName, newEmail);
		
	}
	
	@DeleteMapping("/deleteById")
	public String deleteById(int id){
		return es.deleteEmployeeById(id);
		
	}
	
	@DeleteMapping("/deleteOneEmployee")
	public String deleteOneEmployee(Employee employee){
		es.delateSingleEmployee(employee);
		return "Employee deleted"+employee;
	}
	
	@DeleteMapping("/deleteAllEmployee")
	public String deleteAllEmployee(List<Employee> employee){
		es.deleteAllEmployee(employee);
		return "List of employee deleted"+employee;
	}
	
	@DeleteMapping("/deleteEmployeeInBatch")
	public String deleteAllEmployeeInBatch(){
		es.deleteEmployeeInBatch();
		return "employee deleted in batch";
	}
	

}
