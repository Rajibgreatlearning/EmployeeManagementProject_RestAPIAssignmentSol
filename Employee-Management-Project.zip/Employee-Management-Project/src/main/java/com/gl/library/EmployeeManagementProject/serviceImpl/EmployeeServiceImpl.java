package com.gl.library.EmployeeManagementProject.serviceImpl;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Example;
import org.springframework.data.domain.ExampleMatcher;
import org.springframework.data.domain.Sort;
import org.springframework.data.domain.Sort.Direction;
import org.springframework.stereotype.Service;

import com.gl.library.EmployeeManagementProject.Entity.Employee;
import com.gl.library.EmployeeManagementProject.repository.EmployeeManagementProjectRepository;
import com.gl.library.EmployeeManagementProject.service.EmployeeService;

@Service
public class EmployeeServiceImpl implements EmployeeService {
	@Autowired
	EmployeeManagementProjectRepository empr;

	@Override
	public String addSingleEmployee(Employee employee) {
		empr.save(employee);
		empr.flush();
		return "Employee added in the database";
	}

	@Override
	public String addMultipleEmployee(List<Employee> employee) {
		empr.saveAll(employee);
		empr.flush();
		return "All employee added in the database";
	}

	@Override
	public Employee getEmployeeById(int id) {
		Employee employee = new Employee();
		employee = empr.findById(id).get();
		return employee;
	}

	@Override
	public List<Employee> getAllEmployee() {
		return empr.findAll();

	}

	@Override
	public List<Employee> getAllEmployeeSortedByFirstName() {

		return empr.findAll(Sort.by(Direction.DESC, "firstName"));
	}

	@Override
	public List<Employee> getEmployeeByFirstName(String firstName) {
		List<Employee> employeeList = new ArrayList<Employee>();
		List<Employee> refEmplList = new ArrayList<Employee>();
		Employee employee=new Employee();
		employeeList = empr.findAll();
		Iterator<Employee> it = employeeList.iterator();
		while (it.hasNext()) {
			employee=it.next();
			if (employee.getFirstName().equalsIgnoreCase(firstName)) {
				refEmplList.add(employee);
			}
		}
		return refEmplList;

	}

	/*
	 * @Override public Employee getEmployeeById(int id) {
	 * 
	 * 
	 * }
	 */

	@Override
	public String updateEmployee(int id, String newFirstName, String newLastName, String newEmail) {
		Employee employee = new Employee();
		employee = empr.findById(id).get();
		employee.setEmail(newEmail);
		employee.setFirstName(newFirstName);
		employee.setLastName(newLastName);
		empr.save(employee);
		empr.flush();
		return "Updated in the database: " + id;
	}

	@Override
	public String delateSingleEmployee(Employee employee) {
		empr.delete(employee);
		return "Deleted employee is:" + employee;
	}

	@Override
	public String deleteEmployeeInBatch() {
		empr.deleteAllInBatch();
		return "Deleted all";
	}

	@Override
	public String deleteAllEmployee(List<Employee> employee) {
		empr.deleteAll(employee);
		return "Deleted list of employee";
	}

	@Override
	public String deleteEmployeeById(int id) {
		Employee employee = new Employee();
		employee = empr.findById(id).get();
		empr.delete(employee);
		return "Deleted" + employee;
	}

}
