insert into employee values(1, 'kishanpatel@gmail.com', 'kishan', 'patel');
insert into employee values(2, 'luciatorres@gmail.com', 'lucia', 'torres');
insert into employee values(3, 'tigerguan@gmail.com', 'tiger', 'guan');
insert into employee values(4, 'jillross@gmail.com', 'jill', 'ross');
insert into employee values(5, 'tamaraoconer@gmail.com', 'tamara', 'oconer');
insert into employee values(6, 'kishansingh@gmail.com', 'kishan', 'singh');